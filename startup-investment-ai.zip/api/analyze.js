
import { NextResponse } from "next/server";
import OpenAI from "openai";
import pdfParse from "pdf-parse";
import formidable from "formidable";
import fs from "fs";

export const config = {
  api: {
    bodyParser: false,
  },
};

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async function handler(req, res) {
  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(500).json({ error: "Formularfehler" });
    }

    let inputText = fields.input || "";
    if (files.file) {
      const dataBuffer = fs.readFileSync(files.file.filepath);
      const parsed = await pdfParse(dataBuffer);
      inputText += "\n" + parsed.text;
    }

    const prompt = `Bitte analysiere das folgende Startup anhand dieser 10 Kriterien:
1. Gründerteam & Human Capital
2. Idee & Geschäftsmodell
3. Markt & Wettbewerb
4. Traction & Validierung
5. Finanzen & KPIs
6. Produkt & Technologie
7. Rechtliches & Struktur
8. Vision & Impact
9. Exit-Optionen
10. Investoren-Fit & Dealstruktur

Text: """${inputText}"""`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });

    res.status(200).json({ verdict: "KI-Analyse", criteria: { Antwort: completion.choices[0].message.content } });
  });
}
